(function( $ ) {

	var _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Close menu'		: 'Закрыть меню',
		'Close submenu'		: 'Закрыть подменю',
		'Open submenu' 		: 'Открыть подменю',
		'Toggle submenu' 	: 'Переключить подменю'
	});

})( jQuery );
