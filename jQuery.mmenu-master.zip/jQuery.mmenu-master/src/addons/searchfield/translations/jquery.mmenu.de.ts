(function( $ ) {

	const _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Search'			: 'Suche',
		'No results found.'	: 'Keine Ergebnisse gefunden.',
		'cancel'			: 'beenden'
	});

})( jQuery );